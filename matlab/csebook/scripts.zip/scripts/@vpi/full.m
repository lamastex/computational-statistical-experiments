function N = full(N)
% vpi/full: full
% usage: N = full(N);
%
% arguments: (input)
%  N - a vpi scalar or array
%
%
%  See also: 
%
%
%  Author: John D'Errico
%  e-mail: woodchips@rochester.rr.com
%  Release: 1.0
%  Release date: 1/19/09

% a no-op in vpi land
if nargin ~= 1
  error('full accepts only one argument')
end



