function INT = uplus(INT)
% vpi/uplus: unary plus for an vpi object
% usage: INT = +INT;
% 
% arguments:
%  INT - an vpi object
%
%
%  See also: uminus, plus
%  
% 
%  Author: John D'Errico
%  e-mail: woodchips@rochester.rr.com
%  Release: 1.0
%  Release date: 1/19/09


% its really just a no-op
